data Matrix a = Mat{
nexp :: Int,
mat :: QT a
}
--we introduce a data type in order to store whether the current solution is described by a line or by a point
data Solution a = Equation{ coeff :: a, intercept :: a} | Point { m :: a, q :: a}

data QT a = C a | Q (QT a) (QT a) (QT a) (QT a)



isLinearTransform (Mat sizeA qtA)  (Mat sizeB qtB) = if(sizeA/=sizeB) 
                                                     then Nothing
                                                     else 
                                                         let sol=(isLinearTransformAux (Mat sizeA qtA) (Mat sizeB qtB))
                                                         in case sol of
                                                                Nothing -> Nothing
                                                                Just s -> case s of
                                                                           (Point m q) -> Just (m,q)
                                                                           (Equation a b)-> Just (0,b) --i just calculate the solution in m=0 (così evito un altro if)

--isLinearTransformAux :: (Eq a, Fractional a) => Matrix a -> Matrix a -> Maybe (Solution a)

--sistema sottodeterminato (2 unkonwns 1 equation) -> inf solutions, we repersent q with an equation (q=-B*m+A)
isLinearTransformAux (Mat 0 (C valA)) (Mat 0 (C valB)) = Just ((Equation (-valB) valA))


--abbiamo una matrice A (almeno 2x2) e una matrice B (almeno 2x2), si assume della stessa dimensione,
--il sistema è sovradeterminato, ma i LHS sono uguali, ciò accade anche per gli RHS quindi:
isLinearTransformAux (Mat _ (C valA)) (Mat _ (C valB)) = Just ((Equation (-valB) valA)) 
--si si potrebbero fondere i due casi precedenti, ma sono lasciati separati per chiarezza


--abbiamo una matrice A (almeno 2x2) e una matrice B (almeno 2x2), si assume della stessa dimensione,
--il sistema è sovradeterminato, ma i LHS sono uguali, dunque m=0 e come q il valore del RHS
isLinearTransformAux (Mat _ (C valA)) (Mat _ _) = Just ((Equation 0 valA))

--abbiamo una matrice A (almeno 2x2) e una matrice B (almeno 2x2), si assume della stessa dimensione,
--il sistema è sovradeterminato, ma i LHS sono diversi, NON VI E' SOLUZIONE
isLinearTransformAux (Mat _ (Q qA1 qA2 qA3 qA4)) (Mat _ (C valB)) = Nothing

--general case: we merge the four partial solutions of the submatrices
isLinearTransformAux (Mat sizeA (Q qA1 qA2 qA3 qA4)) (Mat sizeB (Q qB1 qB2 qB3 qB4)) = linearMerge (linearMerge (isLinearTransformAux (Mat (sizeA-1) qA1) (Mat (sizeB-1) qB1))
                                                                                                                (isLinearTransformAux (Mat (sizeA-1) qA2) (Mat (sizeB-1) qB2)))
                                                                                                   (linearMerge (isLinearTransformAux (Mat (sizeA-1) qA3) (Mat (sizeB-1) qB3))
                                                                                                                (isLinearTransformAux (Mat (sizeA-1) qA4) (Mat (sizeB-1) qB4)))

--the first two cases deal with the fact that already one of the two inputs doesn't present a solution, thus no solution exists																									(isLinearTransform (sizeA-1) qA4 qB4))		
linearMerge Nothing _ = Nothing
linearMerge _ Nothing = Nothing
--if the solutions so fare are just two pairs of m and q, then they must be equal in order to have a solution
linearMerge (Just (Point m1 q1)) (Just (Point m2 q2)) = if(q1/=q2 || m1 /= m2)
                                                        then Nothing
                                                        else (Just (Point m1 q1))

--in this case the two q_s must be equal, so (q1=-B*m+A=q2) and we get m, then we check if m is equal to m2, if so we still have a solution
linearMerge (Just (Equation b1 a1)) (Just (Point m2 q2)) = let m = (q2-a1)/b1
                                                           in if(m==m2)
                                                                then (Just (Point m q2))
                                                                else Nothing
--the case specular to the one above
linearMerge  (Just (Point m1 q1)) (Just (Equation b2 a2))= let m = (q1-a2)/b2
                                                           in if(m==m1)
                                                                then (Just (Point m q1))
                                                                else Nothing
--general case, two lines can be:
-- parallel (b1=b2) -> no solution
-- overlapped (b1=b2 & a1=a2) -> solution is the line
-- intersecting else -> solution is a point
linearMerge  (Just (Equation b1 a1)) (Just (Equation b2 a2)) = if(b1==b2)
                                                                 then 
                                                                   if(a1==a2)
                                                                     then 
                                                                        (Just (Equation b2 a2))
                                                                     else
                                                                        Nothing
                                                                  else --we already know b1!=b2
                                                                    let m=(a2-a1)/(b1-b2)
                                                                    in Just (Point m ((m*b2)+a2))                                    

